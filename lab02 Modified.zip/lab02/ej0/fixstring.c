#include <stdbool.h>
#include <assert.h>

#include "fixstring.h"

unsigned int fstring_length(fixstring s) {

    unsigned int result=0;
   
    for (int i = 0; i < FIXSTRING_MAX; i++)
    {
        if (s[i] == '\0')
        {
            return result;
        }
        else
        result++;
        continue;
        
    }
    
    return result;
}

bool fstring_eq(fixstring s1, fixstring s2) {
    
    if (fstring_length(s1)!=fstring_length(s2))
    {
        return false;
    }
    
    for (int i = 0; i < fstring_length(s1); i++)
    {
        if (s1[i]!=s2[i])
        {
            return false;
        }
        else
        continue;
        
    }
    return true;
}


//                  s1 <=  s2

bool fstring_less_eq(fixstring s1, fixstring s2) {

   

    int s1l = fstring_length(s1);
    int s2l = fstring_length(s2);

    
     if (fstring_eq(s1,s2)!=true)
     {
    for (int i = 0; s1[i]!= '\0' && s2[i]!= '\0'; i++)
        {
            if (s1[i]<s2[i])
            {
                return true;
            }
            else
            return false;
            
        }
             }
     
       
    
    
     if (fstring_eq(s1,s2));
    {
        return true;
    }

    
}