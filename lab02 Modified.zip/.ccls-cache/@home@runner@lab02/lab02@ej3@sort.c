#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "array_helpers.h"
#include "sort.h"
#include "sort_helpers.h"

static unsigned int partition(int a[], unsigned int izq, unsigned int der) {
  unsigned int pivot = der;

  int j = izq;

  for (unsigned int i = izq; i < der; i++) {
    if (a[i] <= a[pivot]) {
      swap(a, a[i], a[j]);
      j++;
    }
  }
  swap(a, a[j], a[pivot]);
  pivot = j;
  return pivot;
}

static void quick_sort_rec(int a[], unsigned int izq, unsigned int der) {
  unsigned int ppiv;
  if (der > izq) {
    ppiv = partition(a, izq, der);
    quick_sort_rec(a, izq, ppiv - 1);
    quick_sort_rec(a, ppiv + 1, der);
  }
}

void quick_sort(int a[], unsigned int length) {
  quick_sort_rec(a, 0, (length == 0) ? 0 : length - 1);
}
